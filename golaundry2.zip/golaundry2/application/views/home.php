<!-- Image and text -->


  <div style="margin-top: 0%;" class="d-flex">
    <div class="col-sm-2">
	     </div>

<div class="d-flex justify-content-center">
	<div class="col-xs-8" style="background-color:white;">
	   <h3>Cari Laundry semudah </h3>
	     <h3> mungkin!</h3>
	      <h6>hanya dengan 1 klik bisa mendapatkan laundry yang diinginkan...</h6>
        <form class="" action="<?php echo site_url();?>toko/cari" method="post">
          <input class="form-control mr-sm-2" type="text" name="cari" placeholder="Search" aria-label="Search" class="glyphicon glyphicon-search">
  <!-- <button type="submit" name="button" style="display:hidden!important;">Cari</button> -->
    </form>
    </div>
	</div>

	<div class="col-sm-5  ml-auto align-self-end" style="background-color:white;">
		<img src="gambar/cuci.jpg"  width="250" height="120" >
	</div>
</div>


	<br>
    <h1 style="border-bottom: 5px solid black; border-bottom-width: medium; margin:15px 100px 10px;"></h1>
      <h4 align ="center" ><b>How It Works</b></h4>

    <div class="d-flex" style=" margin-top: 2%; " >
  <div class=" col-sm-2" >
</div>
	<div class="col-md-8" align ="center">
		<div class="row">

<div class=" col-sm-2" >
      <span class="fa-stack">
          <!-- a strong element with the custom content, in this case a number -->
          <strong class="fa-stack-1x" >1</strong>
      </span>
      <p>
        <i class="fas fa-mobile-alt fa-4x"></i>
        <div class="caption" style="font-size:20px; margin-top: 5%">Masuk</div>
      </p>
</div>

<div class="col-sm-2">
      <span class="fa-stack">
          <!-- a strong element with the custom content, in this case a number -->
          <strong class="fa-stack-1x" >2</strong>
      </span>
	    <p>
        <i class="fas fa-store fa-4x"></i>
        <div class="caption" style="font-size:18px;"> Cari Laundry</div>
      </p>
</div>

<div class="col-sm-2 ">
      <span class="fa-stack">
          <!-- a strong element with the custom content, in this case a number -->
          <strong class="fa-stack-1x" >3</strong>
      </span>
	    <p>
        <i class="fas fa-shipping-fast fa-4x"></i>
        <div class="caption" style="font-size:18px;"> Penjemputan</div>
      </p>
</div>

<div class="col-sm-2" align ="center">
      <span class="fa-stack">
          <!-- a strong element with the custom content, in this case a number -->
          <strong class="fa-stack-1x" >4</strong>
      </span>
		  <p>
        <img src="gambar/cucii.jpg "width="60" height="70" style="background-color: white">
        <div class="caption" style="font-size:18px;"> Pencucian</div>
      </p>
</div>

<div class="col-sm-2">
      <span class="fa-stack">
          <!-- a strong element with the custom content, in this case a number -->
          <strong class="fa-stack-1x" >5</strong>
      </span>
	     <p>
         <i class="fas fa-tshirt fa-4x"></i>
         <div class="caption" style="font-size:18px;"> Pakaian Bersih</div>
       </p>
</div>

<div class="col-sm-2">
      <span class="fa-stack">
          <!-- a strong element with the custom content, in this case a number -->
          <strong class="fa-stack-1x" >6</strong>
      </span>
	    <p>
        <i class="fas fa-luggage-cart fa-4x"></i>
        <div class="caption" style="font-size:18px;"> Pengantaran</div>
      </p>
</div>
  </div>
    </div>
	     </div>

       <div class="footer-copyright text-center py-0"  style="width:100%;height:30px;background:black ; color:white; margin: -2px 0px 0px">Copyright GO Laundry 2019
        </div>
