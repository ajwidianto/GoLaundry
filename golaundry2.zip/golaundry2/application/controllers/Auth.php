<?php

class GHome extends CI_Controller
{


   function index()
  {

    
  }



}
?>
